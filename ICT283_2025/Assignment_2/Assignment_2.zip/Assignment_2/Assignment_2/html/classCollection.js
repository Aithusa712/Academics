var classCollection =
[
    [ "Get_sPCC_Data", "classCollection.html#a121415cf1a1968311bd50851f700ca3f", null ],
    [ "GetSolarData", "classCollection.html#a3f74953c16607caea6cac8f59c34b872", null ],
    [ "GetSpeedData", "classCollection.html#a954bc1cce511877e7373333a222c7303", null ],
    [ "GetTempData", "classCollection.html#ad6d940fd6b6a7a32dbfc2b003c4f0542", null ]
];