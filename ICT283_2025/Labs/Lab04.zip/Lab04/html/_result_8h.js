var _result_8h =
[
    [ "Result", "class_result.html", "class_result" ],
    [ "operator<<", "_result_8h.html#af50f81852a9648e8b495b4f8c86f6ec3", null ],
    [ "operator>>", "_result_8h.html#a08c7664c86ccab122b033017c3f653c7", null ],
    [ "MaxUnits", "_result_8h.html#adbf2df14ced2ec93f38b6d43c4d12495", null ]
];