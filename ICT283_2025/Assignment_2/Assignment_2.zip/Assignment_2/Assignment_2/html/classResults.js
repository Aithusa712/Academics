var classResults =
[
    [ "Display_sPCC", "classResults.html#a35fbbd7efee024f4c532c9a8f3eb67be", null ],
    [ "DisplayAverageStdevSpeed", "classResults.html#aab2d1793b03f766af73da66b272697cd", null ],
    [ "DisplayAverageStdevTemperature", "classResults.html#a4a4faf662090164cb2c873e49c4c54b4", null ],
    [ "DisplayTotalSolarRadiation", "classResults.html#ab02523d4983775f3c2255d44934c988e", null ],
    [ "PrintAll", "classResults.html#aef3159df1c45e68eb77af91747358a89", null ]
];