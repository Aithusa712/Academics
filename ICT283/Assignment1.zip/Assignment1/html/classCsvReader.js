var classCsvReader =
[
    [ "readCSV", "classCsvReader.html#ab5b19b9cee08061ec5d148707daaa9ba", null ],
    [ "trim", "classCsvReader.html#a7c90a4ba5a57751bcb8817affcfbf035", null ]
];