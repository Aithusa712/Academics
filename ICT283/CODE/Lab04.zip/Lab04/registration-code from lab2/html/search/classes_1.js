var searchData=
[
  ['registration_0',['Registration',['../classRegistration.html',1,'']]],
  ['result_1',['Result',['../classResult.html',1,'']]]
];
