var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../classCourse.html#a34fb723016b27ed6167580748a679c5d',1,'Course::operator&lt;&lt;'],['../classRegistration.html#a0fd17e4423f843b3a2d6d265ef12419e',1,'Registration::operator&lt;&lt;']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../classCourse.html#a9aad032462b43af24ce44ad784005e14',1,'Course::operator&gt;&gt;'],['../classRegistration.html#ac6e479de58958d2b0a2295ceb04926da',1,'Registration::operator&gt;&gt;']]]
];
