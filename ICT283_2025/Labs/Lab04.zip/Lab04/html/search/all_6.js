var searchData=
[
  ['setcount_0',['SetCount',['../classRegistration.html#a0267d16441c27bce03f341ef4d35a469',1,'Registration']]],
  ['setcredits_1',['SetCredits',['../classUnit.html#a8dfd5c0b5feb22e7e9c482b463accf0b',1,'Unit']]],
  ['setdate_2',['SetDate',['../classResult.html#a82a011482002e890c2b955724a8484dc',1,'Result']]],
  ['setday_3',['SetDay',['../classDate.html#a7b6f3262997530ea44b84dc1ff818690',1,'Date']]],
  ['setmarks_4',['SetMarks',['../classResult.html#a225c8102e558b2f3f54c72812fae4ce2',1,'Result']]],
  ['setmonth_5',['SetMonth',['../classDate.html#aa7814f6054a688039338ac1190d74a8d',1,'Date']]],
  ['setresult_6',['SetResult',['../classRegistration.html#a1b8f67fb70532426fa4214c84fd9eec1',1,'Registration']]],
  ['setsemester_7',['SetSemester',['../classRegistration.html#a680410308e663cdbd23c0eb0ac9ad542',1,'Registration']]],
  ['setstudentid_8',['SetStudentId',['../classRegistration.html#aff8c1a738f6ea932a230712db262180e',1,'Registration']]],
  ['setunit_9',['SetUnit',['../classResult.html#a138e4b9661a9b847b9240d86806dcbef',1,'Result']]],
  ['setunitid_10',['SetUnitId',['../classUnit.html#af556970e2cde1c08c3ae7b42582fdd64',1,'Unit']]],
  ['setunitname_11',['SetUnitName',['../classUnit.html#afcdc59c5f5ee62cffa856fa8dbbde04a',1,'Unit']]],
  ['setyear_12',['SetYear',['../classDate.html#a795790fc0cde4220ceaf13b5ce232e4a',1,'Date']]]
];
