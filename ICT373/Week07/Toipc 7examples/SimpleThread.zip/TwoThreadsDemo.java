/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threadexample1;


// option 1
public class TwoThreadsDemo {
    public static void main (String[] args) {
        SimpleThread task1 = new SimpleThread( "Jamica" );
        SimpleThread task2 = new SimpleThread( "Fiji" );
    
        Thread thread1 = new Thread(task1);
        thread1.start();

        Thread thread2 = new Thread(task2);
        thread2.start();
    }
}



// Optoin 2: concurrent

/*
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class TwoThreadsDemo {
    public static void main (String[] args) {
        SimpleThread task1 = new SimpleThread( "Jamica" );
        SimpleThread task2 = new SimpleThread( "Fiji" );
    
         ExecutorService threadExecutor = 
				Executors.newCachedThreadPool();

      // start threads and place in runnable state
        threadExecutor.execute( task1 ); // start task1
        threadExecutor.execute( task2 ); // start task2

	// shutdown worker threads when their tasks complete
        threadExecutor.shutdown(); 
   
    
    }
}

*/