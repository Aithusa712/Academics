var classRegistration =
[
    [ "Registration", "classRegistration.html#aac811faf22fe96a7f657a282d6d679ab", null ],
    [ "GetCount", "classRegistration.html#a729a2d6ae08aefd2dbe10ec7b3e5ce48", null ],
    [ "GetCredits", "classRegistration.html#a72a5cc800d9551d69e4c201cd9f07ccd", null ],
    [ "operator<<", "classRegistration.html#a0fd17e4423f843b3a2d6d265ef12419e", null ],
    [ "operator>>", "classRegistration.html#ac6e479de58958d2b0a2295ceb04926da", null ]
];