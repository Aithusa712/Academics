var files_dup =
[
    [ "CSVReader.cpp", "CSVReader_8cpp.html", null ],
    [ "CSVReader.h", "CSVReader_8h.html", "CSVReader_8h" ],
    [ "Date.cpp", "Date_8cpp.html", null ],
    [ "Date.h", "Date_8h.html", "Date_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Time.cpp", "Time_8cpp.html", null ],
    [ "Time.h", "Time_8h.html", "Time_8h" ],
    [ "vector.h", "vector_8h.html", "vector_8h" ],
    [ "WindDataCalculator.cpp", "WindDataCalculator_8cpp.html", null ],
    [ "WindDataCalculator.h", "WindDataCalculator_8h.html", "WindDataCalculator_8h" ],
    [ "WindRecType.cpp", "WindRecType_8cpp.html", null ],
    [ "WindRecType.h", "WindRecType_8h.html", "WindRecType_8h" ]
];