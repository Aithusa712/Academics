var SensorRecType_8h =
[
    [ "SensorRecType", "structSensorRecType.html", "structSensorRecType" ],
    [ "SensorLog", "SensorRecType_8h.html#a956d88c53b304980ea47d015240a0c5d", null ]
];