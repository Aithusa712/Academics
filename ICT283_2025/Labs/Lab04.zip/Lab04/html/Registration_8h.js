var Registration_8h =
[
    [ "Registration", "classRegistration.html", "classRegistration" ],
    [ "operator<<", "Registration_8h.html#a0ede077169b370cbaffb104b19d33afa", null ],
    [ "operator>>", "Registration_8h.html#a3826f1533c37bc9d40b99113e512be94", null ],
    [ "MaxResults", "Registration_8h.html#aa4898544bdc09a86fb721b74fa6fd490", null ]
];