var classCalculator =
[
    [ "AverageSpeed", "classCalculator.html#a435b767e89db80654828503be749298d", null ],
    [ "AverageTemperature", "classCalculator.html#a263bef44a9496961f9452c79d0afc844", null ],
    [ "StdDevSpeed", "classCalculator.html#ac50d1b12db66b60a5b6784f70a226610", null ],
    [ "StdDevTemperature", "classCalculator.html#ae755edfd9f7ecc9d6215f583ca48403c", null ],
    [ "TotalSolarRadiation", "classCalculator.html#ac2194024094aebd3cc9b6687c0f37752", null ]
];