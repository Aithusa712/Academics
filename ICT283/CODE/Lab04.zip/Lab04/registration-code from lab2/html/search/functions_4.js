var searchData=
[
  ['registration_0',['Registration',['../classRegistration.html#aac811faf22fe96a7f657a282d6d679ab',1,'Registration']]],
  ['result_1',['Result',['../classResult.html#a90f44667e23d25ccdeac37f00a74657b',1,'Result']]]
];
