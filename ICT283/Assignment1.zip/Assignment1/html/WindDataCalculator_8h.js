var WindDataCalculator_8h =
[
    [ "WindDataCalculator", "classWindDataCalculator.html", "classWindDataCalculator" ],
    [ "WINDDATACALULATOR_H", "WindDataCalculator_8h.html#a974258800d9042402ae7a77418ca550b", null ]
];