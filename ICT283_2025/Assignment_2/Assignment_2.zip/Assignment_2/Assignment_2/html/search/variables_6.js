var searchData=
[
  ['solar_5fradiation_0',['solar_radiation',['../structSensorRecType.html#a0e6f3df667f021ec5945af2bb6d3f835',1,'SensorRecType']]],
  ['speed_1',['speed',['../structSensorRecType.html#a1a4aa1ae3f809a000fa4d37567a85c51',1,'SensorRecType']]]
];
