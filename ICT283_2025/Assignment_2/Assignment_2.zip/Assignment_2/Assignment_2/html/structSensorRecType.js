var structSensorRecType =
[
    [ "operator<", "structSensorRecType.html#a9153eb3c288122918db4b2065aa4c08e", null ],
    [ "operator==", "structSensorRecType.html#a8da51a5f54a9b275bc25f716176ac573", null ],
    [ "operator>", "structSensorRecType.html#aa2d4649bacca27a99ca91824e00e722f", null ],
    [ "date", "structSensorRecType.html#a676ebf36faf8367c82d00bd8bd0706b0", null ],
    [ "solar_radiation", "structSensorRecType.html#a0e6f3df667f021ec5945af2bb6d3f835", null ],
    [ "speed", "structSensorRecType.html#a1a4aa1ae3f809a000fa4d37567a85c51", null ],
    [ "temperature", "structSensorRecType.html#a150bbcd884d76f0895111b67f781023b", null ],
    [ "time", "structSensorRecType.html#abf78dac926fec35766935a65722f1583", null ]
];