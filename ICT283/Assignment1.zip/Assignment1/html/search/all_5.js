var searchData=
[
  ['readcsv_0',['readCSV',['../classCsvReader.html#ab5b19b9cee08061ec5d148707daaa9ba',1,'CsvReader']]],
  ['roundoff_1',['roundOff',['../classWindDataCalculator.html#ac92f1b237abfb452c0a15905dcf48594',1,'WindDataCalculator']]]
];
