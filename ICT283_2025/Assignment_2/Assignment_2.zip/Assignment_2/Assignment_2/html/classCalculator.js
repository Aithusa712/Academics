var classCalculator =
[
    [ "Calculate_sPCC", "classCalculator.html#a3a3e1bc63004d4b645e164feba9ed73c", null ],
    [ "CalculateAverage", "classCalculator.html#a3a67e4f9efeff3d9105babf64a6c3223", null ],
    [ "CalculateMAD", "classCalculator.html#aa5cb508ff94a8084fec44cf84270f502", null ],
    [ "CalculateStandardDeviation", "classCalculator.html#ac2df88bb90f09985f9f44dc20ce252da", null ],
    [ "CalculateTotalSolarRadiation", "classCalculator.html#aa70e3d02acd2ad3211484334a5ed9ae4", null ]
];