var classResult =
[
    [ "Result", "classResult.html#a90f44667e23d25ccdeac37f00a74657b", null ],
    [ "~Result", "classResult.html#ab83cf33a31236b3da75d66aaf9a05ed0", null ],
    [ "GetDate", "classResult.html#a5fb8e0ff5cb49916ec5657d4298d1633", null ],
    [ "GetMark", "classResult.html#a0e7197fdcdd4df22b182e2518ab87130", null ],
    [ "GetUnit", "classResult.html#afd973c5783ece727554be5c6036ddd67", null ],
    [ "SetDate", "classResult.html#a00c7a6a0d2202eaeb5bd2a62afcdeeb1", null ],
    [ "SetMark", "classResult.html#af78d4374e34ebefcace359c664b5e9ee", null ],
    [ "SetUnit", "classResult.html#afa924341881402d45d00702e7bf88886", null ]
];