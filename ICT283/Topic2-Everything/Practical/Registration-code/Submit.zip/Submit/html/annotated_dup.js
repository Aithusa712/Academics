var annotated_dup =
[
    [ "Course", "classCourse.html", "classCourse" ],
    [ "Registration", "classRegistration.html", "classRegistration" ]
];