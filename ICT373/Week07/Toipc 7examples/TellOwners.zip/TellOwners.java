/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package companyownership;

/**
 *
 * @author 20150534
 */
//TellOwners.java
/*
The main method here works about one third of the times when it is executed.
The rest of the time it gets deadlocked.
*/
public class TellOwners extends Thread {
    private Company company;
    
    public TellOwners(Company company){
        this.company=company;
    }//end constructor
	
    public void run(){
	company.tellSubsidiaries();
    	System.out.println("Information Collection for " +company.name()+" finished.");
    }//end run
		
    public static Company[] makeSomeUp(){
	Company ansett= new Company("ansett");
	Company skywest= new Company("skywest");
	Company airNZ= new Company("airNZ");
	Company qantas= new Company("qantas");

        ansett.owns(skywest);
	skywest.owns(ansett);
	airNZ.owns(ansett);
	
        Company[] Company= {ansett, airNZ, qantas, skywest};
            return Company;
    }
	
    public static void main(String[] args)
        throws InterruptedException{

	Company[] Company= makeSomeUp();
		
	int nr=Company.length;
	TellOwners[] tellThread=new TellOwners[nr];
	
        for (int i=0; i<nr; i++)
            tellThread[i]= new TellOwners(Company[i]);

		//start the threads to collect data
	for (int i=0; i<nr; i++)
            tellThread[i].start();
		
		//wait for the data collection threads 
		//to all finish
	for (int i=0; i<nr; i++)
	    tellThread[i].join();
		
		//list the information gathered
	for (int i=0; i<nr; i++)
            Company[i].listOwners();
		
	System.out.println("Main finished.");
		
    }//end main
		
}//end class TellOwners


