var structNode =
[
    [ "Node", "structNode.html#a58e0335bca10b828bf51d1786df4b83c", null ],
    [ "bfactor", "structNode.html#a59d3eae11626c4e2a900592a3bf4bf22", null ],
    [ "info", "structNode.html#a21995784db5e7ad18061f631c5875635", null ],
    [ "left", "structNode.html#a6596c7ac17ecafff5522310c0da3a828", null ],
    [ "right", "structNode.html#a4009a1138f2f04372037fbec63406f11", null ]
];