var searchData=
[
  ['left_0',['left',['../structNode.html#a6596c7ac17ecafff5522310c0da3a828',1,'Node']]]
];
