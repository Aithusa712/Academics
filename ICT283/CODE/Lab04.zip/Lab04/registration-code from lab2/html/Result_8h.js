var Result_8h =
[
    [ "Result", "classResult.html", "classResult" ],
    [ "operator<<", "Result_8h.html#a2e13a0ca3334614b1fbb0af9bccabeff", null ],
    [ "operator>>", "Result_8h.html#a922b496face9874eea211c8a306fe213", null ]
];