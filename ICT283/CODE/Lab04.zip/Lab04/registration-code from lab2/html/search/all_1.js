var searchData=
[
  ['getcount_0',['GetCount',['../classRegistration.html#a729a2d6ae08aefd2dbe10ec7b3e5ce48',1,'Registration']]],
  ['getcredits_1',['GetCredits',['../classRegistration.html#a72a5cc800d9551d69e4c201cd9f07ccd',1,'Registration::GetCredits()'],['../classUnit.html#ab1f83a3955a721e46730773747e4e67e',1,'Unit::GetCredits()']]],
  ['getdate_2',['GetDate',['../classDate.html#a7bc854f7381a39dda0c2dd0ca2589344',1,'Date::GetDate()'],['../classResult.html#a5fb8e0ff5cb49916ec5657d4298d1633',1,'Result::GetDate() const']]],
  ['getmark_3',['GetMark',['../classResult.html#a0e7197fdcdd4df22b182e2518ab87130',1,'Result']]],
  ['getresults_4',['GetResults',['../classRegistration.html#a6c9a86696e6574e5d83dbb899c5171e1',1,'Registration']]],
  ['getsemester_5',['GetSemester',['../classRegistration.html#a4c1f5de4ca28183644910b90de6856eb',1,'Registration']]],
  ['getstudentid_6',['GetStudentId',['../classRegistration.html#ab8864cecbcbc90e8a70e9d004af31925',1,'Registration']]],
  ['getunit_7',['GetUnit',['../classResult.html#afd973c5783ece727554be5c6036ddd67',1,'Result']]],
  ['getunitid_8',['GetUnitId',['../classUnit.html#a8952641afc157ff469bd4c85f664e71f',1,'Unit']]],
  ['getunitname_9',['GetUnitName',['../classUnit.html#a4fe683b797b0e2814be2ffffa2c19bbe',1,'Unit']]]
];
