var structWindRecType =
[
    [ "getDate", "structWindRecType.html#a90a762a95922127d506ca360d67fbf0a", null ],
    [ "getSolarRadiation", "structWindRecType.html#a1a614397312b577355b632f5d3e69e2d", null ],
    [ "getSpeed", "structWindRecType.html#abb28b25d126f5194750fb6ead9b8117f", null ],
    [ "getTemperature", "structWindRecType.html#aed628c77a3589d669978da4e7835f302", null ],
    [ "getTime", "structWindRecType.html#a437c93788e141c2525eecaabf570d377", null ],
    [ "setDate", "structWindRecType.html#a55c24477023d6a6ef0af9a0edde4ec68", null ],
    [ "setSolarRadiation", "structWindRecType.html#a6c0f77ffe702ba54780cc3c58ebbbb58", null ],
    [ "setSpeed", "structWindRecType.html#ae93a146f64253457db29f8e947a39d40", null ],
    [ "setTemperature", "structWindRecType.html#a716e9014237155f70f5287637ec9163a", null ],
    [ "setTime", "structWindRecType.html#af12c1ca05ae7190aee325ef28228f89d", null ]
];