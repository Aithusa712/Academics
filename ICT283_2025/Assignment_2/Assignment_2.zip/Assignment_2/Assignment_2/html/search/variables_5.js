var searchData=
[
  ['right_0',['right',['../structNode.html#a4009a1138f2f04372037fbec63406f11',1,'Node']]],
  ['root_1',['root',['../classBst.html#a58cf9307599ab510c789b153cf170192',1,'Bst']]]
];
