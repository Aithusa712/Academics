var searchData=
[
  ['maxcourses_0',['MaxCourses',['../regist_8h.html#ab25b60dda84db104dc226855d3814d03',1,'regist.h']]]
];
