var searchData=
[
  ['bfactor_0',['bfactor',['../structNode.html#a59d3eae11626c4e2a900592a3bf4bf22',1,'Node']]]
];
