var searchData=
[
  ['info_0',['info',['../structNode.html#a21995784db5e7ad18061f631c5875635',1,'Node']]]
];
