var Time_8h =
[
    [ "Time", "classTime.html", "classTime" ],
    [ "ConvertTime", "Time_8h.html#a87c0105b97c0527901b793422d403c5d", null ],
    [ "operator<<", "Time_8h.html#a1030d33220cad368b7b8640250cd6970", null ],
    [ "operator>>", "Time_8h.html#a57b25f84743fe83ba85ba9ae6a5c2e66", null ]
];