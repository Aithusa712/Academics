var indexSectionsWithContent =
{
  0: "cdgmprstvw~",
  1: "cdtvw",
  2: "cdmtvw",
  3: "cdgmprstv~",
  4: "w",
  5: "w"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Typedefs",
  5: "Macros"
};

