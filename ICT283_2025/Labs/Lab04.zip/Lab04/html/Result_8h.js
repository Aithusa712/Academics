var Result_8h =
[
    [ "Result", "classResult.html", "classResult" ],
    [ "operator<<", "Result_8h.html#a906d41b871e4c1778e208ea670cb8da2", null ],
    [ "operator>>", "Result_8h.html#a096960caa96c5de2f0477470d88d3dd9", null ]
];