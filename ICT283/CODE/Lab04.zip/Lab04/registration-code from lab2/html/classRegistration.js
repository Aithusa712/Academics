var classRegistration =
[
    [ "Registration", "classRegistration.html#aac811faf22fe96a7f657a282d6d679ab", null ],
    [ "GetCount", "classRegistration.html#a729a2d6ae08aefd2dbe10ec7b3e5ce48", null ],
    [ "GetCredits", "classRegistration.html#a72a5cc800d9551d69e4c201cd9f07ccd", null ],
    [ "GetResults", "classRegistration.html#a6c9a86696e6574e5d83dbb899c5171e1", null ],
    [ "GetSemester", "classRegistration.html#a4c1f5de4ca28183644910b90de6856eb", null ],
    [ "GetStudentId", "classRegistration.html#ab8864cecbcbc90e8a70e9d004af31925", null ],
    [ "SetCount", "classRegistration.html#a8806e95a1f1159a9c0b317bcb6104a6f", null ],
    [ "SetResult", "classRegistration.html#abe46a7795a78e390cb42c1147ba4d2f8", null ],
    [ "SetSemester", "classRegistration.html#a30bc191dbd0ec35e961c6682b2833a3b", null ],
    [ "SetStudentId", "classRegistration.html#aff8c1a738f6ea932a230712db262180e", null ]
];