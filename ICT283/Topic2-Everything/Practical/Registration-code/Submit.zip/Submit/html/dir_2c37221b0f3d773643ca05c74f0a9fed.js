var dir_2c37221b0f3d773643ca05c74f0a9fed =
[
    [ "course.h", "course_8h.html", "course_8h" ],
    [ "regist.h", "regist_8h.html", "regist_8h" ]
];