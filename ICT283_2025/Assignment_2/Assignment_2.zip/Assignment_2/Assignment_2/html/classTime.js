var classTime =
[
    [ "Time", "classTime.html#a4245e409c7347d1d671858962c2ca3b5", null ],
    [ "GetHours", "classTime.html#a508c3a20933ad90eb9ba0339c51d949d", null ],
    [ "GetMinutes", "classTime.html#a776335efdef4b465085442f046699b38", null ],
    [ "SetHours", "classTime.html#acf86e36cf192aea46bc8387e2fa35cac", null ],
    [ "SetMinutes", "classTime.html#ab93488db2aa9a41fec6a24e68c341262", null ]
];