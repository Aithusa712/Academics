var searchData=
[
  ['handlemonthlyspeed_0',['HandleMonthlySpeed',['../classMenu.html#a1692acad1cdf7ea5115467a4d0669efd',1,'Menu']]]
];
