var dir_a208ec3c23e13bcb9171551f9696a8df =
[
    [ "course.h", "course_8h.html", "course_8h" ],
    [ "regist.h", "regist_8h.html", "regist_8h" ]
];