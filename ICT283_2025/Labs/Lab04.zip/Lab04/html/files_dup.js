var files_dup =
[
    [ "Date.cpp", "Date_8cpp.html", "Date_8cpp" ],
    [ "Date.h", "Date_8h.html", "Date_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Registration.cpp", "Registration_8cpp.html", "Registration_8cpp" ],
    [ "Registration.h", "Registration_8h.html", "Registration_8h" ],
    [ "Result.cpp", "Result_8cpp.html", "Result_8cpp" ],
    [ "Result.h", "Result_8h.html", "Result_8h" ],
    [ "Unit.cpp", "Unit_8cpp.html", "Unit_8cpp" ],
    [ "Unit.h", "Unit_8h.html", "Unit_8h" ]
];