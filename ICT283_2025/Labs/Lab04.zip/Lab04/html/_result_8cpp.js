var _result_8cpp =
[
    [ "operator<<", "_result_8cpp.html#af50f81852a9648e8b495b4f8c86f6ec3", null ],
    [ "operator>>", "_result_8cpp.html#a08c7664c86ccab122b033017c3f653c7", null ]
];