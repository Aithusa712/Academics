var searchData=
[
  ['_7edate_0',['~Date',['../classDate.html#ade4b469433b7966cc034cbcc6799233b',1,'Date']]],
  ['_7eresult_1',['~Result',['../classResult.html#ab83cf33a31236b3da75d66aaf9a05ed0',1,'Result']]]
];
