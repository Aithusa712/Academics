var classDate =
[
    [ "Date", "classDate.html#a4e59ed4ba66eec61c27460c5d09fa1bd", null ],
    [ "~Date", "classDate.html#ade4b469433b7966cc034cbcc6799233b", null ],
    [ "GetDate", "classDate.html#a7bc854f7381a39dda0c2dd0ca2589344", null ],
    [ "SetDate", "classDate.html#ad62ff590543681469652347d01139092", null ]
];