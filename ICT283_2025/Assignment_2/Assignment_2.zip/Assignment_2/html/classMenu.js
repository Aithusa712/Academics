var classMenu =
[
    [ "GetValidYear", "classMenu.html#acdb35007ed6ed2b1cf476776edde519d", null ],
    [ "HandleMonthlySpeed", "classMenu.html#a1692acad1cdf7ea5115467a4d0669efd", null ],
    [ "prompt", "classMenu.html#a042879989da9d5ba48f2e5091ca7de61", null ]
];