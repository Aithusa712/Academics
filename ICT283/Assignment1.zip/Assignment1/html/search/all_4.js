var searchData=
[
  ['push_0',['push',['../classVector.html#a771cb9fc1c1941bcef009df2b55f3c72',1,'Vector']]]
];
