var regist_8h =
[
    [ "Registration", "classRegistration.html", "classRegistration" ],
    [ "MaxCourses", "regist_8h.html#ab25b60dda84db104dc226855d3814d03", null ]
];