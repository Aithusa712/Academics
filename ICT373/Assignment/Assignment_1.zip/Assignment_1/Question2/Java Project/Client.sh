#!/bin/bash 
java -jar Client.jar
