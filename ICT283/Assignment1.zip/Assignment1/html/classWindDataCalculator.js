var classWindDataCalculator =
[
    [ "calculateAll", "classWindDataCalculator.html#af0a69963fe39b52243a2b4856d4fcf01", null ],
    [ "calculateAvg", "classWindDataCalculator.html#aafb8875c9e9ac954e8cf20839ef6e283", null ],
    [ "calculateAvgSpeed", "classWindDataCalculator.html#ae7dbd07b5e3d6196d2b6d72d475fea16", null ],
    [ "calculateAvgSR", "classWindDataCalculator.html#aff91569f8a39cf2ab8343e163116c43e", null ],
    [ "calculateAvgTemp", "classWindDataCalculator.html#a9fed217324b48400dc673f01e4324252", null ],
    [ "calculateStd", "classWindDataCalculator.html#ae3236343ed4b4241e157df9fe8b11a8f", null ],
    [ "checkMonth", "classWindDataCalculator.html#a08cb45ae79a76426dadf0bb9b39bab21", null ],
    [ "GetMonthlyData", "classWindDataCalculator.html#a0c94ccaf09a9ae6721f57302ef02c09d", null ],
    [ "roundOff", "classWindDataCalculator.html#ac92f1b237abfb452c0a15905dcf48594", null ]
];