var searchData=
[
  ['date_0',['date',['../structSensorRecType.html#a676ebf36faf8367c82d00bd8bd0706b0',1,'SensorRecType']]]
];
