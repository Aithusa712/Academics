var Regist_8cpp =
[
    [ "operator<<", "Regist_8cpp.html#a0fd17e4423f843b3a2d6d265ef12419e", null ],
    [ "operator>>", "Regist_8cpp.html#ac6e479de58958d2b0a2295ceb04926da", null ]
];