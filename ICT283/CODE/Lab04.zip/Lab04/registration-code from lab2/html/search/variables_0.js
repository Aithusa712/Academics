var searchData=
[
  ['maxresults_0',['MaxResults',['../Regist_8h.html#acaceade9084d64028f3558082708ebae',1,'Regist.h']]]
];
