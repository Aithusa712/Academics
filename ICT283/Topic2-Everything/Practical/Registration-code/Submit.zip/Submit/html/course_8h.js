var course_8h =
[
    [ "Course", "classCourse.html", "classCourse" ],
    [ "CourseNameSize", "course_8h.html#a0a074da20a0006b8526250383bf5855a", null ]
];