var classUnit =
[
    [ "Unit", "classUnit.html#a8e46f663a95736c8002d85ab271a7581", null ],
    [ "GetCredits", "classUnit.html#ab1f83a3955a721e46730773747e4e67e", null ],
    [ "GetUnitId", "classUnit.html#a8952641afc157ff469bd4c85f664e71f", null ],
    [ "GetUnitName", "classUnit.html#a4fe683b797b0e2814be2ffffa2c19bbe", null ],
    [ "SetCredits", "classUnit.html#ac7948114e8b030f070e2975929f6b5ea", null ],
    [ "SetunitId", "classUnit.html#a01d9a3bfa5c34b1fae2e15733bfe4679", null ],
    [ "SetunitName", "classUnit.html#a03264e25f8418b6092d780032062392c", null ]
];