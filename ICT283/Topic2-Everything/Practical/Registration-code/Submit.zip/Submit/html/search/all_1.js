var searchData=
[
  ['getcount_0',['GetCount',['../classRegistration.html#a729a2d6ae08aefd2dbe10ec7b3e5ce48',1,'Registration']]],
  ['getcredits_1',['GetCredits',['../classCourse.html#a0d6ecc51cf62d796d6c795a7e9d76aa0',1,'Course::GetCredits()'],['../classRegistration.html#a72a5cc800d9551d69e4c201cd9f07ccd',1,'Registration::GetCredits()']]]
];
