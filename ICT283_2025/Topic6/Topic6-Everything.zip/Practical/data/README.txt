For assignment 1, read only one data file.

The data file must reside in this data folder.

You can declare that file name as a constant at the top of main.cpp (file that has the routine main()