var classRegistration =
[
    [ "Registration", "classRegistration.html#aac811faf22fe96a7f657a282d6d679ab", null ],
    [ "GetCount", "classRegistration.html#a8e26bff537aa274bf94cebf7b087cc3b", null ],
    [ "GetCredits", "classRegistration.html#afabf42fd073fb661dcefa0008ac7c789", null ],
    [ "GetResult", "classRegistration.html#a493c27ebc2641917d4ccf934500eb726", null ],
    [ "GetSemester", "classRegistration.html#a978d2a48b603303d79d446f4852d6106", null ],
    [ "GetStudentId", "classRegistration.html#ab8864cecbcbc90e8a70e9d004af31925", null ],
    [ "SetCount", "classRegistration.html#a0267d16441c27bce03f341ef4d35a469", null ],
    [ "SetResult", "classRegistration.html#a1b8f67fb70532426fa4214c84fd9eec1", null ],
    [ "SetSemester", "classRegistration.html#a680410308e663cdbd23c0eb0ac9ad542", null ],
    [ "SetStudentId", "classRegistration.html#aff8c1a738f6ea932a230712db262180e", null ]
];