var searchData=
[
  ['getcount_0',['GetCount',['../classRegistration.html#a8e26bff537aa274bf94cebf7b087cc3b',1,'Registration']]],
  ['getcredits_1',['GetCredits',['../classRegistration.html#afabf42fd073fb661dcefa0008ac7c789',1,'Registration::GetCredits()'],['../classResult.html#ac511a5edd379f1a7f352846a92fe51f4',1,'Result::GetCredits()'],['../classUnit.html#a706b9f300fbe47c02967f750692a2166',1,'Unit::GetCredits()']]],
  ['getdate_2',['GetDate',['../classResult.html#a845c6e50d22472412109ee3e024f4e94',1,'Result']]],
  ['getday_3',['GetDay',['../classDate.html#a6304a67f1c13b239eb8e80ad68161e40',1,'Date']]],
  ['getmarks_4',['GetMarks',['../classResult.html#a7539cee3f1b5fe653f13ef46a780615f',1,'Result']]],
  ['getmonth_5',['GetMonth',['../classDate.html#af2dcc6ce51dbb2bd798499a149bdffb7',1,'Date']]],
  ['getresult_6',['GetResult',['../classRegistration.html#a493c27ebc2641917d4ccf934500eb726',1,'Registration']]],
  ['getsemester_7',['GetSemester',['../classRegistration.html#a978d2a48b603303d79d446f4852d6106',1,'Registration']]],
  ['getstudentid_8',['GetStudentId',['../classRegistration.html#ab8864cecbcbc90e8a70e9d004af31925',1,'Registration']]],
  ['getunit_9',['GetUnit',['../classResult.html#a5bcb14520ba30b744cc524a90e951f74',1,'Result']]],
  ['getunitid_10',['GetUnitId',['../classUnit.html#a8952641afc157ff469bd4c85f664e71f',1,'Unit']]],
  ['getunitname_11',['GetUnitName',['../classUnit.html#a4fe683b797b0e2814be2ffffa2c19bbe',1,'Unit']]],
  ['getyear_12',['GetYear',['../classDate.html#ad79ce504482f317ddcfdc4ecad77671f',1,'Date']]]
];
