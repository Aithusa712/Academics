var searchData=
[
  ['setcredits_0',['SetCredits',['../classCourse.html#ab889c7d28b861ef596262d032330410e',1,'Course']]]
];
