var annotated_dup =
[
    [ "CsvReader", "classCsvReader.html", "classCsvReader" ],
    [ "Date", "classDate.html", "classDate" ],
    [ "Time", "classTime.html", "classTime" ],
    [ "Vector", "classVector.html", "classVector" ],
    [ "WindDataCalculator", "classWindDataCalculator.html", "classWindDataCalculator" ],
    [ "WindRecType", "structWindRecType.html", "structWindRecType" ]
];