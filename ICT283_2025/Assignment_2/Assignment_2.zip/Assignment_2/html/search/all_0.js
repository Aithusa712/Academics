var searchData=
[
  ['averagespeed_0',['AverageSpeed',['../classCalculator.html#a435b767e89db80654828503be749298d',1,'Calculator']]],
  ['averagetemperature_1',['AverageTemperature',['../classCalculator.html#a263bef44a9496961f9452c79d0afc844',1,'Calculator']]]
];
