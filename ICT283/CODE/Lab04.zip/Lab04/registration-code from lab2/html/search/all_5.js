var searchData=
[
  ['setcount_0',['SetCount',['../classRegistration.html#a8806e95a1f1159a9c0b317bcb6104a6f',1,'Registration']]],
  ['setcredits_1',['SetCredits',['../classUnit.html#ac7948114e8b030f070e2975929f6b5ea',1,'Unit']]],
  ['setdate_2',['SetDate',['../classDate.html#ad62ff590543681469652347d01139092',1,'Date::SetDate()'],['../classResult.html#a00c7a6a0d2202eaeb5bd2a62afcdeeb1',1,'Result::SetDate(const Date &amp;date)']]],
  ['setmark_3',['SetMark',['../classResult.html#af78d4374e34ebefcace359c664b5e9ee',1,'Result']]],
  ['setresult_4',['SetResult',['../classRegistration.html#abe46a7795a78e390cb42c1147ba4d2f8',1,'Registration']]],
  ['setsemester_5',['SetSemester',['../classRegistration.html#a30bc191dbd0ec35e961c6682b2833a3b',1,'Registration']]],
  ['setstudentid_6',['SetStudentId',['../classRegistration.html#aff8c1a738f6ea932a230712db262180e',1,'Registration']]],
  ['setunit_7',['SetUnit',['../classResult.html#afa924341881402d45d00702e7bf88886',1,'Result']]],
  ['setunitid_8',['SetunitId',['../classUnit.html#a01d9a3bfa5c34b1fae2e15733bfe4679',1,'Unit']]],
  ['setunitname_9',['SetunitName',['../classUnit.html#a03264e25f8418b6092d780032062392c',1,'Unit']]]
];
