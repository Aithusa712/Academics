var files_dup =
[
    [ "registration-code from lab2", "dir_07c7ff53da2ec1883e9f43b2d7a30b96.html", "dir_07c7ff53da2ec1883e9f43b2d7a30b96" ]
];