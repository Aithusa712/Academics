var Registration_8cpp =
[
    [ "operator<<", "Registration_8cpp.html#a0ede077169b370cbaffb104b19d33afa", null ],
    [ "operator>>", "Registration_8cpp.html#a3826f1533c37bc9d40b99113e512be94", null ]
];