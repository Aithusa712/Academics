var WindRecType_8h =
[
    [ "WindRecType", "structWindRecType.html", "structWindRecType" ],
    [ "WindlogType", "WindRecType_8h.html#a88706fe5fd0f20a328df141f3756f4a4", null ]
];