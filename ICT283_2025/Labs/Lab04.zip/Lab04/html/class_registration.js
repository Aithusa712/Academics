var class_registration =
[
    [ "Registration", "class_registration.html#aac811faf22fe96a7f657a282d6d679ab", null ],
    [ "GetCount", "class_registration.html#a729a2d6ae08aefd2dbe10ec7b3e5ce48", null ],
    [ "GetCredits", "class_registration.html#a72a5cc800d9551d69e4c201cd9f07ccd", null ],
    [ "GetResult", "class_registration.html#a493c27ebc2641917d4ccf934500eb726", null ],
    [ "GetSemester", "class_registration.html#a4c1f5de4ca28183644910b90de6856eb", null ],
    [ "GetStudentId", "class_registration.html#ab8864cecbcbc90e8a70e9d004af31925", null ],
    [ "SetCount", "class_registration.html#a8806e95a1f1159a9c0b317bcb6104a6f", null ],
    [ "SetResult", "class_registration.html#abb41da56002bf64e9db2e4a09dd5bcfa", null ],
    [ "SetSemester", "class_registration.html#a30bc191dbd0ec35e961c6682b2833a3b", null ],
    [ "SetStudentId", "class_registration.html#aff8c1a738f6ea932a230712db262180e", null ]
];