var searchData=
[
  ['calculator_0',['Calculator',['../classCalculator.html',1,'']]],
  ['collection_1',['Collection',['../classCollection.html',1,'']]]
];
