var searchData=
[
  ['coursenamesize_0',['CourseNameSize',['../course_8h.html#a0a074da20a0006b8526250383bf5855a',1,'course.h']]]
];
