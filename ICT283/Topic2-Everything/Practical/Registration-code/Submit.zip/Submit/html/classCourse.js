var classCourse =
[
    [ "Course", "classCourse.html#a6b959ccf15d9ceed9e9c14a701561982", null ],
    [ "Course", "classCourse.html#ac2121e059c09d6f311a5499fa4c3fb1c", null ],
    [ "GetCredits", "classCourse.html#a0d6ecc51cf62d796d6c795a7e9d76aa0", null ],
    [ "SetCredits", "classCourse.html#ab889c7d28b861ef596262d032330410e", null ],
    [ "operator<<", "classCourse.html#a34fb723016b27ed6167580748a679c5d", null ],
    [ "operator>>", "classCourse.html#a9aad032462b43af24ce44ad784005e14", null ]
];