var _registration_8cpp =
[
    [ "operator<<", "_registration_8cpp.html#a11fafbd3f2e74179c493a4e8df2d9931", null ],
    [ "operator>>", "_registration_8cpp.html#ac567a84ce171cae4d55b94b519f17d72", null ]
];