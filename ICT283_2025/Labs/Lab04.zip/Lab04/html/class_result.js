var class_result =
[
    [ "Result", "class_result.html#a90f44667e23d25ccdeac37f00a74657b", null ],
    [ "GetCredits", "class_result.html#ab4772c61e1094931099000f5792aeaa6", null ],
    [ "GetMarks", "class_result.html#aad8239a4cc32f14eb6f529c6abca8094", null ],
    [ "GetUnit", "class_result.html#a5bcb14520ba30b744cc524a90e951f74", null ],
    [ "SetMarks", "class_result.html#ad3787b97e872d6cec60b80de54e4a24c", null ],
    [ "SetUnit", "class_result.html#a138e4b9661a9b847b9240d86806dcbef", null ]
];