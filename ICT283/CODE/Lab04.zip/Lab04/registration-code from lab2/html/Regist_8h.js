var Regist_8h =
[
    [ "Registration", "classRegistration.html", "classRegistration" ],
    [ "operator<<", "Regist_8h.html#a0fd17e4423f843b3a2d6d265ef12419e", null ],
    [ "operator>>", "Regist_8h.html#ac6e479de58958d2b0a2295ceb04926da", null ],
    [ "MaxResults", "Regist_8h.html#acaceade9084d64028f3558082708ebae", null ]
];