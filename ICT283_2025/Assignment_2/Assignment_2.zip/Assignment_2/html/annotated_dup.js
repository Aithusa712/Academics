var annotated_dup =
[
    [ "Calculator", "classCalculator.html", "classCalculator" ],
    [ "Date", "classDate.html", "classDate" ],
    [ "FileHandler", "classFileHandler.html", "classFileHandler" ],
    [ "Menu", "classMenu.html", "classMenu" ],
    [ "Results", "classResults.html", "classResults" ],
    [ "SensorRecType", "structSensorRecType.html", "structSensorRecType" ],
    [ "Time", "classTime.html", "classTime" ],
    [ "Vector", "classVector.html", "classVector" ]
];