var classTime =
[
    [ "Time", "classTime.html#a4245e409c7347d1d671858962c2ca3b5", null ],
    [ "~Time", "classTime.html#a1e92dbe963fa3cdd6bea207680f5f6d1", null ],
    [ "GetTime", "classTime.html#a9b76678c4580b88d8c292a0d5b8e65f0", null ],
    [ "SetTime", "classTime.html#a53cf358919b9cb1313b816320e536314", null ]
];