var classUnit =
[
    [ "Unit", "classUnit.html#a8e46f663a95736c8002d85ab271a7581", null ],
    [ "GetCredits", "classUnit.html#a706b9f300fbe47c02967f750692a2166", null ],
    [ "GetUnitId", "classUnit.html#a8952641afc157ff469bd4c85f664e71f", null ],
    [ "GetUnitName", "classUnit.html#a4fe683b797b0e2814be2ffffa2c19bbe", null ],
    [ "SetCredits", "classUnit.html#a8dfd5c0b5feb22e7e9c482b463accf0b", null ],
    [ "SetUnitId", "classUnit.html#af556970e2cde1c08c3ae7b42582fdd64", null ],
    [ "SetUnitName", "classUnit.html#afcdc59c5f5ee62cffa856fa8dbbde04a", null ]
];