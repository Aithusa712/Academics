var class_unit =
[
    [ "Unit", "class_unit.html#a8e46f663a95736c8002d85ab271a7581", null ],
    [ "Unit", "class_unit.html#addba0193993823f9f532350d3dc3209f", null ],
    [ "GetCredits", "class_unit.html#ab1f83a3955a721e46730773747e4e67e", null ],
    [ "GetUnitId", "class_unit.html#a8952641afc157ff469bd4c85f664e71f", null ],
    [ "GetUnitName", "class_unit.html#a4fe683b797b0e2814be2ffffa2c19bbe", null ],
    [ "SetCredits", "class_unit.html#a30da0a139292d627ca978e272f3af753", null ],
    [ "SetUnitId", "class_unit.html#af556970e2cde1c08c3ae7b42582fdd64", null ],
    [ "SetUnitName", "class_unit.html#afcdc59c5f5ee62cffa856fa8dbbde04a", null ]
];