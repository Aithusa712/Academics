var classResult =
[
    [ "Result", "classResult.html#a90f44667e23d25ccdeac37f00a74657b", null ],
    [ "ConvertDate", "classResult.html#a51bbdbbc4aeb111ff261909c58e68d17", null ],
    [ "GetCredits", "classResult.html#ac511a5edd379f1a7f352846a92fe51f4", null ],
    [ "GetDate", "classResult.html#a845c6e50d22472412109ee3e024f4e94", null ],
    [ "GetMarks", "classResult.html#a7539cee3f1b5fe653f13ef46a780615f", null ],
    [ "GetUnit", "classResult.html#a5bcb14520ba30b744cc524a90e951f74", null ],
    [ "SetDate", "classResult.html#a82a011482002e890c2b955724a8484dc", null ],
    [ "SetMarks", "classResult.html#a225c8102e558b2f3f54c72812fae4ce2", null ],
    [ "SetUnit", "classResult.html#a138e4b9661a9b847b9240d86806dcbef", null ]
];