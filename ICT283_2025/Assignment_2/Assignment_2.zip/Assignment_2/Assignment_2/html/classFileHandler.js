var classFileHandler =
[
    [ "readCSV", "classFileHandler.html#ab915f132c8eac7e38ef32235be498903", null ],
    [ "readSource", "classFileHandler.html#a157090e8ab86e0064796eb6992041a38", null ],
    [ "writeToFile", "classFileHandler.html#a89530c8ca2d597f40ead571fb7ce41f4", null ]
];